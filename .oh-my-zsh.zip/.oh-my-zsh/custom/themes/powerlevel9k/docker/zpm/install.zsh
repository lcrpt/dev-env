# install zpm
git clone --recursive https://github.com/zpm-zsh/zpm.git ~/.zpm

# Install powerlevel9k
mkdir ~/.zpm/plugins/powerlevel9k
ln -s ~/p9k/powerlevel9k.zsh-theme ~/.zpm/plugins/powerlevel9k/powerlevel9k.plugin.zsh
